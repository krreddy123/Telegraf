$ToolsFolder = "C:\tools"
$version = '1.22.4'
Invoke-WebRequest ('https://dl.influxdata.com/telegraf/releases/telegraf-{0}_windows_amd64.zip' -f $version) -OutFile telegraf.zip

Expand-Archive -Path telegraf.zip -DestinationPath $ToolsFolder
Start-Sleep 10
Get-ChildItem ('{0}/telegraf-{1}' -f $ToolsFolder,$version)
Rename-Item ('{0}/telegraf-{1}' -f $ToolsFolder,$version) ('{0}/telegraf' -f $ToolsFolder)

New-Item -Path ('{0}/telegraf/telegraf.d' -f $ToolsFolder) -type Directory | Out-Null
C:\tools\telegraf\telegraf.exe --service install --config C:\tools\telegraf.conf --config-directory C:\tools\telegraf\telegraf.d | Out-Null
Stop-Service telegraf | Out-Null
Remove-Item -Path telegraf.zip

